<?php
if(isset($_POST['submit'])){
    $to = "info@odhavramoverseas.com";
    $cc = "info.shreeodhavramoverseas@gmail.com";

    $from = $_POST['email'];
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $message = $name . " "  . " wrote the following:" . "\n" . $_POST['message'];

    $headers = 'From: '.$from."\r\n".
        'Reply-To: '.$from."\r\n" .
        'X-Mailer: PHP/' . phpversion();

    mail($to,$subject,$message,$headers);
    mail($cc,$subject,$message,$headers);

    header('Location: contact.php');
}
?>

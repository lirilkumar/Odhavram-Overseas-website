<html lang="en">
<?php $selected = "home" ?>
<?php include('master_header.php');?>

<section id="carouselSection" style="text-align:center">
    <div id="myCarousel" class="carousel slide">
        <div class="carousel-inner">
            <div  style="text-align:center"  class="item active">
                <div class="wrapper"><img src="images/banner/business_website_templates_1.jpg" alt="business webebsite template">
                    <div class="carousel-caption">
                        <h4>Manufacturer and Exporter</h4>
                        <p>We specialise in manufacturing and packaging, and Export of all Spices, Dry Fruits,Rice, Ghee, herbal and Agro Commodities. We Export all commodities all around the world.</p>
                        <a href="services.php" class="btn btn-medium btn-success">More</a>
                    </div>
                </div>
            </div>
            <div  style="text-align:center"  class="item">
                <div class="wrapper"><img src="images/banner/business_website_templates_2.jpg" alt="business themes">
                    <div class="carousel-caption">
                        <h4>Spices</h4>
                        <p>We Manufacture, Process and Package various spices including Cardamom, Clove, Black pepper, Cassia bark, Cumin, Coriander, Nutmeg and mace, Mustard seeds, Fenugreek, Turmeric, Saffron. This all products are supplied in various packaging according to cuctomer requirment.</p>
                        <a href="services.php" class="btn btn-medium btn-success">More</a>
                    </div>
                </div>
            </div>
            <div  style="text-align:center"  class="item">
                <div class="wrapper"><img src="images/banner/business_website_templates_3.jpg" alt="business themes">
                    <div class="carousel-caption">
                        <h4>Rice</h4>
                        <p>Wide range of Export Quality rice are processed and packaged. varieties include red, brown, white, Sticky Rice, Parboiled Rice, Black Rice, Basmati Rice, Jasmin Rice. </p>
                        <a href="services.php" class="btn btn-medium btn-success">More</a>
                    </div>
                </div>
            </div>
            <div  style="text-align:center"  class="item">
                <div class="wrapper"><img src="images/banner/business_website_templates_4.jpg" alt="business themes">
                    <div class="carousel-caption">
                        <h4>Herbal products</h4>
                        <p>We specialise in web design, web development and graphic design for different Desktop, Mobiles and Tablets.  We recently introduce cheapest and best mobile web design packages in our services.  </p>
                        <a href="services.php" class="btn btn-medium btn-success">More</a>
                    </div>
                </div>
            </div>
            <div  style="text-align:center"  class="item">
                <div class="wrapper"><img src="images/banner/business_website_templates_5.jpg" alt="business themes">
                    <div class="carousel-caption">
                        <h4>Dry Fruits and Ghee</h4>
                        <p>Dry fruits ranging from walnut, almonds, cashew nut, fig, date as well as unique dryfruit variants such as honey almonds, Ajwa Dates, medjool dates, Dried Blueberries, cranberries are all available. We have a variety of dry fruits to keep your sweet tooth and your nutritious diet in balance. </p>
                        <a href="services.php" class="btn btn-medium btn-success">More</a>
                    </div>
                </div>
            </div>
        </div>
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
    </div>
</section>
<!-- Sectionone ends ======================================== -->
<section id="middleSection">
    <div class="container">
        <div class="row" style="text-align:center">
            <div class="span12">
                <div class="well well-small">
                    <div class="well well-small">
                        <img src="images/logo/full%20logo.png" width="500px">
                    </div>
                    <p style="text-align: left">"Over a period of 33 years our company Shree Odhavram Overseas has expanded Globally. We have strengthened our Position in Local Market and we have also shaped ourselves into a Major Player in the International Market.<br>
                        Our Drive for Business, have made us Leading Indian Exporters of Spices, Blended Spices, Rice, Ghee, Herbal and Agro Products, Dry Fruits and various other Indian Foods.<br>
                        At Shree Odhavram Overseas, we believe in personal commitment and responsibility which focuses on providing Quality products thereby resulting in client satisfaction. We take personal interest in monitoring every stage of the production process such as procurement and inspection, lab analysis and quality control, packaging and loading of goods. Due to this expertise we have a better understanding of the products we sell and therefore a better understanding of how best to serve our clients."<br/><br/></p>
                </div>
            </div>
            <div class="span2">
                <div class="well well-small">
                    <p>Spices</p>
                    <img src="images/products_spices/ajwain.jpg">
                </div>
            </div>
            <div class="span2">
                <div class="well well-small">
                    <p>Grain</p>
                    <img src="images/products_grain/Millet%20-%20Bajra.jpg">
                </div>
            </div>
            <div class="span2">
                <div class="well well-small">
                    <p>Rice</p>
                    <img src="images/products_rice/basmati%20rice.jpg">
                </div>
            </div>
            <div class="span2">
                <div class="well well-small">
                    <p>Dry Fruits</p>
                    <img src="images/products_dry_fruits/Chestnut.jpg">
                </div>
            </div>
            <div class="span2">
                <div class="well well-small">
                    <p>Herbal</p>
                    <img src="images/products_herbal/peppermint%20leaves.jpg">
                </div>
            </div>
            <div class="span2">
                <div class="well well-small">
                    <p>Pulses</p>
                    <img src="images/products_pulses/Kidney%20Beans,%20Beans.jpg">
                </div>
            </div>
        </div>
    </div>
</section>
<section id="bodySection">
    <div class="container">
        <div class="row">
            <h3 class="span12" style="text-align:center">Work Domain <small>(Business Process)</small></h3>
            <div class="span4">
                <div class="thumbnail">
                    <h4>Purchase and Processing</h4>
                    <a href="aboutus.php"><img src="images/domains/purchase.jpg" alt="bootstrap business templates"></a>
                    <p>
                        <br/>
                        We clean, process, manufacture by standardised machines used worldwide. <br/>
                    </p>
                </div>
            </div>
            <div class="span4">
                <div class="thumbnail">
                    <h4>Packaging</h4>
                    <a href="aboutus.php"><img src="images/domains/packaging.jpg" alt="bootstrap business templates"></a>
                    <p>
                        <br/>
                        Packaging is available on customer reuirment from small packages to large boxes.
                        <br/>
                    </p>
                </div>
            </div>
            <div class="span4">
                <div class="thumbnail">
                    <h4>Export and Sell</h4>
                    <a href="aboutus.php"><img src="images/domains/export.png" alt="bootstrap business templates"></a>
                    <p>
                        <br/>
                        Exported worldwide by standardise and fast process. export quality products are sold across globe.
                        <br/>
                    </p>
                </div>
            </div>
        </div>
        <br/>
    </div>
</section>
<!-- body block end======================================== -->
<?php include('master_footer.php');?>
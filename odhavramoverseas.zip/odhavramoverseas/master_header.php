<head>
    <meta charset="utf-8">
    <title>ShreeOdhavramOverseas</title>
    <link rel="icon" href="images/logo/favicon.ico" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <link id="callCss" rel="stylesheet" href="themes/current/bootstrap.min.css" type="text/css" media="screen"/>
    <link href="themes/css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css">
    <link href="themes/css/font-awesome.css" rel="stylesheet" type="text/css">
    <link href="themes/css/base.css" rel="stylesheet" type="text/css">
    <style type="text/css" id="enject"></style>
</head>
<body>
<section id="headerSection">
    <div class="container">
        <div class="navbar">
            <div class="container">
                <button type="button" class="btn btn-navbar active" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="brand" href="index.html"> <img src="images/logo/logo.png" alt="logo" height="90px" width="90px">Shree Odhavram Overseas<small style="font-size: 12px">  Manufacturer and Exporter </small></a>
                <br><br><br><div class="nav-collapse collapse" style="padding-bottom: 10px;">
                    <ul class="nav pull-right">
                        <li class="<?php if ($selected == "home") echo 'active'; ?>"><a href="index.php">Home	</a></li>
                        <li class="<?php if ($selected == "services") echo 'active'; ?>"><a href="services.php">Services</a></li>
                        <li class="<?php if ($selected == "products") echo 'active'; ?>"><a href="products.php">Products</a></li>
                        <li class="<?php if ($selected == "aboutus") echo 'active'; ?>"><a href="aboutus.php">About Us</a></li>
                        <li class="<?php if ($selected == "contact") echo 'active'; ?>"><a href="contact.php">Contact Us</a></li>
<!--                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Features<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="elements.html">Page Elements</a></li>
                                <li><a href="comingsoon.html">Coming soon page</a></li>
                            </ul>
                        </li>
-->

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Header Ends================================================ -->

<html lang="en">
<?php $selected = "contact" ?>
<?php include('master_header.php');?>
<!-- body block start======================================== -->
<section id="mapSection">
    <div id="myMap" style="height:400px">
        <!-- please edit in (js code which is available in the foote section) longitude and longitude of your location  -->
    </div>
</section>

<section id="bodySection">
    <div class="container">
        <div class="row">
            <div class="span4">
                <h3>  Mailing Address </h3>
                Shree Odhavram Overseas<br>
                D-2, APMC Market, <br>
                Phase-II, Sector-19, <br>
                Mudibazar, Vashi,<br>
                Navi Mumbai - 400703.<br><br>
                Phone: <br>
                <i class="icon-phone-sign"></i> &nbsp; +91 99202 30292 <br>
                <i class="icon-phone-sign"></i> &nbsp; +91 88795 00135 <br>
            </div>
            <div class="span4">
                <h3> Opening Hours</h3>
                <h4> Monday - Friday</h4>
                09:00am - 09:00pm<br/><br/>
                <h4>Saturday</h4>
                09:00am - 07:00pm<br/><br/>
                <h4>Sunday</h4>
                Closed<br/><br/>
            </div>
            <div class="span4">
                <h3>  Email Us</h3>
                <form class="form-horizontal" method="post" action="mail_handler.php">
                    <fieldset>
                        <div class="control-group">

                            <input type="text" name="name" placeholder="name" class="input-xlarge" required/>

                        </div>
                        <div class="control-group">

                            <input type="email" name="email" placeholder="email" class="input-xlarge" required/>

                        </div>
                        <div class="control-group">

                            <input type="text" name="subject" placeholder="subject" class="input-xlarge" required/>

                        </div>
                        <div class="control-group">
                            <textarea rows="4" name="message" id="textarea" class="input-xlarge" required></textarea>

                        </div>

                        <input class="btn btn-large" type="submit"  name="submit" value="Send Message"> </input>

                    </fieldset>
                </form>
            </div>
        </div>

    </div>
</section>


<!-- body block end======================================== -->
<?php include('master_footer.php');?>
<!-- Google map jquery files -->
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&key=AIzaSyBWyOzSNf4bfZGGPbYXcWqA0D44FFDuUMo"></script>
<script src="themes/js/jquery.gmap.js"></script>
<script>
    // Google map data ==============================================================================
    $(document).ready(function(){
        $("#myMap").gMap({ controls: false,
            scrollwheel: false,
            draggable: true,
            markers: [{ latitude: 19.0758089,  		//your company location latitude
                longitude: 73.0074464,		//your company location longitude
                icon: { image: "http://www.google.com/mapfiles/marker.png",
                    iconsize: [42, 48],
                    iconanchor: [42,48],
                    infowindowanchor: [14, 0] } },
            ],
            icon: { image: "http://www.google.com/mapfiles/marker.png",
                iconsize: [28, 48],
                iconanchor: [14, 48],
                infowindowanchor: [14, 0] },
            latitude: 19.0758089,
            longitude: 73.0074464,
            zoom: 18, });
    });
</script>



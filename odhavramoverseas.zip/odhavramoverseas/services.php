<html lang="en" xmlns="http://www.w3.org/1999/html">
<?php $selected = "services" ?>
<?php include('master_header.php');?>

<!-- body block start======================================== -->

<!-- Page banner -->
<section id="bannerSection" style="background:url(themes/images/banner/aboutus.png) no-repeat center center #000;">
    <div class="container" >
        <h1 id="pageTitle">Services
		<span class="pull-right toolTipgroup">
			<a href="#" data-placement="top" data-original-title="Find us on via facebook"><img style="width:45px" src="themes/images/facebook.png" alt="facebook" title="facebook"></a>
			<a href="#" data-placement="top" data-original-title="Find us on via twitter"><img style="width:45px" src="themes/images/twitter.png" alt="twitter" title="twitter"></a>
			<a href="#" data-placement="top" data-original-title="Find us on via youtube"><img style="width:45px" src="themes/images/youtube.png" alt="youtube" title="youtube"></a>
		</span>
        </h1>
    </div>
</section>
<!-- Page banner end -->
<section id="bodySection">
    <div class="container">
        <div class="row">
            <div class="span3">
                <div class="well well-small">
                    <h3>Payment Methods Accepted</h3>
                    <ul  style="text-align: left; padding:0px;">
                        <li>Advance payment</li>
                        <li>Letter of credit.( L.C.)</li>
                        <li>Documents against Payments</li>
                        <li>Documents against Acceptance</li>
                    </ul>
                </div>
                <br/>

<!--                <h4>Payment Methods Accepted</h4>
                <ul class="media-list">

                    <li class="media well well-small">
                        <a class="pull-left" href="#">
                            <img class="media-object" src="themes/images/img64x64.png" alt="bootstrap business template"/>
                        </a>
                        <div class="media-body">
                            Net Banking
                        </div>
                    </li>
                    <li class="media well well-small">
                        <a class="pull-left" href="#">
                            <img class="media-object" src="themes/images/img64x64.png" alt="bootstrap business template"/>
                        </a>
                        <div class="media-body">
                            Paytm <strong>747845478</strong>
                        </div>
                    </li>
                </ul>


-->            </div>
                <div class="span9">
                <div class="well well-small" style="text-align:left">
                    <h3>We provide</h3>
                    <p><img src="images/services.jpg" alt="business templates" /></p>
                    <h4>Our Philosophy</h4>
                    Shree Odhavram Overseas and Locally known as 'Shree Odhavram Traders' is leading in market of manufacturing and export of pulses, spices, dry fruits, grains etc.<br>
                    We provide below services to customers,
                    <ul>
                        <li><strong>Quotation :</strong> Before ordering us, we also provide customers quotations of listed products. attractive offers are also available on specific time, i.e. festivals, off season.</li>
                        <li><strong>Packaging :</strong> Different packaging options are available according to customer requirement. We are totally customer oriented whenit comes to packaging</li>
                        <li><strong>Delivey   :</strong> Fast delivery is one of our strength. our transportation and CHA partner made it possible to deliver your cargo or shipment lightning fast.</li>
                        <li><strong>Transactions  :</strong> We follow all standard of international Trading and it's various payment methods.</li>
                    </ul>

                    </p>

                    <br/>
                    <ul class="media-list">
                        <li class="media well well-small">
                            <a class="pull-left" href="#">
                                <img class="media-object" src="images/export.jpg" alt="image" width="200px"/>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">Countries where we export.</h4>
                                <table>
                                    <tr>
                                        <td>
                                            <ul  style="text-align: left; padding:0px;">
                                                <li>Malaysia</li>
                                                <li>Singapore</li>
                                                <li>Sri lanka</li>
                                                <li>Thailand</li>
                                                <li>Vietnam</li>
                                            </ul>
                                        </td>
                                        <td>
                                            <ul  style="text-align: left; padding:0px;">
                                                <li>Oman</li>
                                                <li>Yemen</li>
                                                <li>U.A.E</li>
                                                <li>Djibouti</li>
                                                <li>Saudi Arabia</li>
                                            </ul>
                                        </td>
                                        <td>
                                            <ul  style="text-align: left; padding:0px;">
                                                <li>Kenya</li>
                                                <li>Somalia</li>
                                                <li>Mauritius</li>
                                                <li>Somalia</li>
                                                <li>Maldives</li>
                                            </ul>
                                        </td>
                                        <td>
                                            <ul  style="text-align: left; padding:0px;">
                                                <li>Hong Kong</li>
                                                <li>Madagascar</li>
                                                <li>U.K</li>
                                                <li>U.S</li>
                                                <li>New Zealand</li>
                                            </ul>
                                        </td>
                                        <td>
                                            <ul  style="text-align: left; padding:0px;">
                                                <li>Taiwan</li>
                                            </ul>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- body block end======================================== -->
<?php include('master_footer.php');?>
<html lang="en" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
<?php $selected = "aboutus" ?>
<?php include('master_header.php');?>

<!-- body block start======================================== -->

<!-- Page banner -->
<section id="bannerSection" style="background:url(themes/images/banner/aboutus.png) no-repeat center center #000;">
    <div class="container" >
        <h1 id="pageTitle">About us
		<span class="pull-right toolTipgroup">
			<a href="#" data-placement="top" data-original-title="Find us on via facebook"><img style="width:45px" src="themes/images/facebook.png" alt="facebook" title="facebook"></a>
			<a href="#" data-placement="top" data-original-title="Find us on via twitter"><img style="width:45px" src="themes/images/twitter.png" alt="twitter" title="twitter"></a>
			<a href="#" data-placement="top" data-original-title="Find us on via youtube"><img style="width:45px" src="themes/images/youtube.png" alt="youtube" title="youtube"></a>
		</span>
        </h1>
    </div>
</section>
<!-- Page banner end -->
<section id="bodySection">
    <div class="container">
        <div class="row">
            <div class="span3">
                <div class="well well-small">
                    <h3>Customer Profile</h3>
                    We are always in constant touch with our customers all over the world and study their market needs. We keep them informed about the international market conditions and factors affecting the market prices.<br/><br/>
                    We have a strong client base. We export our goods to more than<strong> 25 countries</strong>. More than 75% of our customers are the leading importers of their respective countries. Our customers have gained substantially by dealing through us.<br/>
                    They have full confidence in us not only in respect of timely consignment from our end but also information regarding international market conditions which helps them to maximise their profits. We firmly believe that the customers are our real assets and customer satisfaction is our final goal.<br>
                </div>
                <br/>


            </div>
            <div class="span9">
                <div class="well well-small" style="text-align:left">
                    <h3>Shree Odhavram Overseas.</h3>
                    <p><img src="images/about%20us.jpg" alt="business templates" /></p>
                    <h4>Our Philosophy</h4>
                    <p><strong>1.Strong Customer Orientation :</strong>We work in close coordination with our clients and develop, produce and supply products customized to their needs with regard to a. Product Quality b. Food Safety and Hygiene c. Packaging d. Supply Schedule. We seek continuous feedback regarding our products from our customers and make improvements/modifications where ever required. We maintain record for full traceability for all the products we export. Root cause analysis is carried to identify the main cause and loopholes are plugged to ensure there is no repetition of the problems faced. All our system and processes are geared to meet the expectations of our esteemed customer.<br>
                    <p><strong>2.Sharp focus on product quality, safety and Hygiene :</strong>Since the company has to compete in the most stringent quality conscious markets of the world everyone from top management to the shop floor worker is oriented towards maintaining standards benchmarked to the best in the world. The company adopts good manufacturing and storage practices and has set up approved and proven systems and procedures to maintain such stringent standards.Shree Odhavram Overseas is committed towards product quality, hygiene and safety. Quality Orientation has strong presence in every aspect of supply chain. Top management of the company is directly involved in and responsible for planning, controlling and development of our Quality Management Systems. The efficiency and efficacy of this system is reviewed periodically to keep pace with the latest developments and upgrade it.<br/>

                    </p>

                    <br/>
                    <ul class="media-list">
                        <li class="media well well-small">
                            <div class="media-body">
                                <h4 class="media-heading">Shree Odhavram Traders</h4>
                                In local market, we trade on name of 'Shree odhavram Traders' and supply quality products all across Mumbai, Maharastra as well as diffrent states of India. We also buy our raw material from diffrent states of india where products are grown in best natural environment.
                            </div>
                        </li>
                        <li class="media well well-small">
                            <div class="media-body">
                                <h4 class="media-heading">Awards</h4>
                                <strong> Bombay Mudibazar kariana Merchant's Association</strong><small> Privilaged Member for Specialization in <strong>Dhania, Spices and Kirana</strong></small>
                                <img class="media-object" src="images/award.jpeg" alt="image" style=" width:500px"/>

                            </div>
                        </li>
                        <li class="media well well-small">
                            <a class="pull-left" href="#">
                                <img class="media-object" src="images/membership.jpg" alt="image" width="200px"/>
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">Our Commitments</h4>
                                We believe that change is the integral part of our growth which prompts us to provide superior quality products according to the "Changing Tastes" and the "Changing Trends" in the market. <br>
                                Customer has been the centre of all our activities. We maintain transparency in all our business transactions. <br>
                                Tailor-made quality and variety of products according to the need of the customers is our speciality.<br>
                                Besides providing quality goods, we keep our customers informed about the changing market trends to enable them to work out their business strategies.<br>
                                We are bound to our commitments to our customers even given market fluctuations, thus enabling them get an edge over other competitors.<br>
                                ShreeOdhavramOverseas has successfully established business relations with more than 25 countries by forming a chain of dedicated customers across the globe and has shown a remarkable rise in business year after year.<br/>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- body block end======================================== -->
<?php include('master_footer.php');?>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<?php $selected = "products" ?>
<?php include('master_header.php');?>

<!-- body block start======================================== -->

<!-- Page banner -->
<section id="bannerSection" style="background:url(themes/images/banner/portfolio.png) no-repeat center center #000;">
    <div class="container" >
        <h1 id="pageTitle">Products Showcase
		<span class="pull-right toolTipgroup">
			<a href="#" data-placement="top" data-original-title="Find us on via facebook"><img style="width:45px" src="themes/images/facebook.png" alt="facebook" title="facebook"></a>
			<a href="#" data-placement="top" data-original-title="Find us on via twitter"><img style="width:45px" src="themes/images/twitter.png" alt="twitter" title="twitter"></a>
			<a href="#" data-placement="top" data-original-title="Find us on via youtube"><img style="width:45px" src="themes/images/youtube.png" alt="youtube" title="youtube"></a>
		</span>
        </h1>
    </div>
</section>
<!-- Page banner end -->
<section id="bodySection">
    <div id="sectionTwo">
        <div class="container">
            <div class="row">
                <div class="span9">
                    <div class="row">
                        <div class="span9">
                            <ul class="nav nav-pills pull-left">
                                <li class="active"><a href="#spices" data-toggle="tab">Spices</a></li>
                                <li class=""><a href="#rice" data-toggle="tab">Rice</a></li>
                                <li class=""><a href="#dry_fruits" data-toggle="tab">Dry Fruits</a></li>
                                <li class=""><a href="#herbal" data-toggle="tab">Herbal</a></li>
                                <li class=""><a href="#pulses" data-toggle="tab">Pulses</a></li>
                                <li class=""><a href="#grains" data-toggle="tab">Grains</a></li>
                                <li class=""><a href="#oilseeds" data-toggle="tab">Oil Seeds</a></li>
                            </ul>
                        </div>

                        <!-- ========================= -->

                        <div class="span9">
                            <div class="tabbable tabs">
                                <div class="tab-content label-primary">
                                    <div class="tab-pane active" id="spices">
                                        <ul class="thumbnails">
                                            <?php
                                            $files = glob("images/products_spices/*.*");
                                            for ($i=0; $i<count($files); $i++)
                                            {
                                                $image = $files[$i];
                                                $supported_file = array(
                                                    'gif',
                                                    'jpg',
                                                    'jpeg',
                                                    'png'
                                                );
                                                $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                                if (in_array($ext, $supported_file)) {
                                                    $file = basename($image);
                                                    $info = pathinfo($file);
                                                    $name = basename($file,'.'.$info['extension']);


                                                    //displaying box
                                                    echo '
                                                        <li class="span2">
                                                            <div class="thumbnail"  style="width: 150px; height: 160px">
                                                                <div class="blockDtl" style="margin: 14px;" >
                                                                    <h6>'.$name.'</h6>
                                                                    <a href="#"><img src="'.$image .'" alt="liril"/></a>
                                                                </div>
                                                            </div>
                                                        </li>';
                                                    //echo $name;
                                                    //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
                                                } else {
                                                    continue;
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                    <div class="tab-pane" id="rice">
                                        <ul class="thumbnails">
                                            <?php
                                            $files = glob("images/products_rice/*.*");
                                            for ($i=0; $i<count($files); $i++)
                                            {
                                                $image = $files[$i];
                                                $supported_file = array(
                                                    'gif',
                                                    'jpg',
                                                    'jpeg',
                                                    'png'
                                                );
                                                $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                                if (in_array($ext, $supported_file)) {
                                                    $file = basename($image);
                                                    $info = pathinfo($file);
                                                    $name = basename($file,'.'.$info['extension']);


                                                    //displaying box
                                                    echo '
                                                        <li class="span2">
                                                            <div class="thumbnail"  style="width: 150px; height: 160px"">
                                                                <div class="blockDtl" style="margin: 14px;" >
                                                                    <h6>'.$name.'</h6>
                                                                    <a href="#"><img src="'.$image .'" alt="liril"/></a>
                                                                </div>
                                                            </div>
                                                        </li>';
                                                    //echo $name;
                                                    //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
                                                } else {
                                                    continue;
                                                }
                                            }
                                            ?>
                                        </ul>

                                    </div>
                                    <div class="tab-pane" id="dry_fruits">
                                        <ul class="thumbnails">
                                            <?php
                                            $files = glob("images/products_dry_fruits/*.*");
                                            for ($i=0; $i<count($files); $i++)
                                            {
                                                $image = $files[$i];
                                                $supported_file = array(
                                                    'gif',
                                                    'jpg',
                                                    'jpeg',
                                                    'png'
                                                );
                                                $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                                if (in_array($ext, $supported_file)) {
                                                    $file = basename($image);
                                                    $info = pathinfo($file);
                                                    $name = basename($file,'.'.$info['extension']);


                                                    //displaying box
                                                    echo '
                                                        <li class="span2">
                                                            <div class="thumbnail"  style="width: 150px; height: 160px"">
                                                                <div class="blockDtl" style="margin: 14px;" >
                                                                    <h6>'.$name.'</h6>
                                                                    <a href="#"><img src="'.$image .'" alt="liril"/></a>
                                                                </div>
                                                            </div>
                                                        </li>';
                                                    //echo $name;
                                                    //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
                                                } else {
                                                    continue;
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                    <div class="tab-pane" id="herbal">
                                        <ul class="thumbnails">
                                            <?php
                                            $files = glob("images/products_herbal/*.*");
                                            for ($i=0; $i<count($files); $i++)
                                            {
                                                $image = $files[$i];
                                                $supported_file = array(
                                                    'gif',
                                                    'jpg',
                                                    'jpeg',
                                                    'png'
                                                );
                                                $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                                if (in_array($ext, $supported_file)) {
                                                    $file = basename($image);
                                                    $info = pathinfo($file);
                                                    $name = basename($file,'.'.$info['extension']);


                                                    //displaying box
                                                    echo '
                                                        <li class="span2">
                                                            <div class="thumbnail"  style="width: 150px; height: 160px"">
                                                                <div class="blockDtl" style="margin: 14px;" >
                                                                    <h6>'.$name.'</h6>
                                                                    <a href="#"><img src="'.$image .'" alt="liril"/></a>
                                                                </div>
                                                            </div>
                                                        </li>';
                                                    //echo $name;
                                                    //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
                                                } else {
                                                    continue;
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                    <div class="tab-pane" id="pulses">
                                        <ul class="thumbnails">
                                            <?php
                                            $files = glob("images/products_pulses/*.*");
                                            for ($i=0; $i<count($files); $i++)
                                            {
                                                $image = $files[$i];
                                                $supported_file = array(
                                                    'gif',
                                                    'jpg',
                                                    'jpeg',
                                                    'png'
                                                );
                                                $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                                if (in_array($ext, $supported_file)) {
                                                    $file = basename($image);
                                                    $info = pathinfo($file);
                                                    $name = basename($file,'.'.$info['extension']);


                                                    //displaying box
                                                    echo '
                                                        <li class="span2">
                                                            <div class="thumbnail"  style="width: 150px; height: 160px"">
                                                                <div class="blockDtl" style="margin: 14px;" >
                                                                    <h6>'.$name.'</h6>
                                                                    <a href="#"><img src="'.$image .'" alt="liril"/></a>
                                                                </div>
                                                            </div>
                                                        </li>';
                                                    //echo $name;
                                                    //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
                                                } else {
                                                    continue;
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                    <div class="tab-pane" id="grains">
                                        <ul class="thumbnails">
                                            <?php
                                            $files = glob("images/products_grain/*.*");
                                            for ($i=0; $i<count($files); $i++)
                                            {
                                                $image = $files[$i];
                                                $supported_file = array(
                                                    'gif',
                                                    'jpg',
                                                    'jpeg',
                                                    'png'
                                                );
                                                $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                                if (in_array($ext, $supported_file)) {
                                                    $file = basename($image);
                                                    $info = pathinfo($file);
                                                    $name = basename($file,'.'.$info['extension']);


                                                    //displaying box
                                                    echo '
                                                        <li class="span2">
                                                            <div class="thumbnail"  style="width: 150px; height: 160px"">
                                                                <div class="blockDtl" style="margin: 14px;" >
                                                                    <h6>'.$name.'</h6>
                                                                    <a href="#"><img src="'.$image .'" alt="liril"/></a>
                                                                </div>
                                                            </div>
                                                        </li>';
                                                    //echo $name;
                                                    //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
                                                } else {
                                                    continue;
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                    <div class="tab-pane" id="oilseeds">
                                        <ul class="thumbnails">
                                            <?php
                                            $files = glob("images/products_oil_seed_nuts/*.*");
                                            for ($i=0; $i<count($files); $i++)
                                            {
                                                $image = $files[$i];
                                                $supported_file = array(
                                                    'gif',
                                                    'jpg',
                                                    'jpeg',
                                                    'png'
                                                );
                                                $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                                if (in_array($ext, $supported_file)) {
                                                    $file = basename($image);
                                                    $info = pathinfo($file);
                                                    $name = basename($file,'.'.$info['extension']);


                                                    //displaying box
                                                    echo '
                                                        <li class="span2">
                                                            <div class="thumbnail"  style="width: 150px; height: 160px"">
                                                                <div class="blockDtl" style="margin: 14px;" >
                                                                    <h6>'.$name.'</h6>
                                                                    <a href="#"><img src="'.$image .'" alt="liril"/></a>
                                                                </div>
                                                            </div>
                                                        </li>';
                                                    //echo $name;
                                                    //echo '<img src="'.$image .'" alt="Random image" />'."<br /><br />";
                                                } else {
                                                    continue;
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                            </div> <!-- /tabbable -->


                        </div>
                    </div>
                    <!-- ========================= -->
                </div>
                <div class="span3">
                    <ul class="media-list">
                        <li class="media well well-small">
                            <h4>Sub Categories</h4>
                            <p>
                                All listed products are available in diffrent categories, varieties, packing and quality. This Products might be also available in form of powder, raw or processed.
                            </p>
                        </li>
                        <li>
                            <h4>Want Estimation ?</h4>
                        </li>
                        <li class="media well well-small">
                            <div class="media-body">
                                <img class="media-object" src="images/calculator.jpg" alt="bootstrap business template" width="100px"/>
                                Type mail including details of order and address od delivery.
                                <small> Please mention your contact number and name in Email..</small><a class="pull-right" href="contact.php"><strong>Send mail regarding Estimation</strong></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

        </div>

    </div>
</section>

<!-- body block end======================================== -->
<?php include('master_footer.php');?>